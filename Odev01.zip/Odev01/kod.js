
const quizzes=[
    {
        answer_0:"images/kopekresmi.jpg",
        answer_1:"images/kopekresmi.jpg",
        answer_2:"images/kediresmi.jpg",
        indexOfRightAnswer:2

    },
    {
        answer_0:"images/kopekresmi.jpg",
        answer_1:"images/kediresmi.jpg",
        answer_2:"images/köpekresmi.jpg",
        indexOfRightAnswer:1

    }
]
let latesIndex;
const newGame=()=>{
    let  index=Math.floor(Math.random()*quizzes.length);
    if (latesIndex==index){
        index=(index+1)%quizzes.length;
    }
    const quiz=quizzes[index];
    latesIndex=index;
    console.log(index);

}

function change() {


            var image = document.getElementById('img0');
            image.src = "images/kediresmi.png"


            var image1 = document.getElementById('img1');
            image1.src = "images/kopekresmi.jpg"

            var image2 = document.getElementById('img2');
            image2.src = "images/kopek.jpg"

}
function showDialog(mesaj) {
    document.getElementById("alert-text").innerHTML = text;
    document.getElementById("my-alert").style.display = "block";
}
function butonfonksiyonu(){
    alert("yeni oyuna hoşgeldiniz.");
    return newGame();
}


