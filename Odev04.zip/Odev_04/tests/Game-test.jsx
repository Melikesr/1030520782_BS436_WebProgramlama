const  React= require('react');
const {mount}=require('enzyme');
const {Game}=require('../src/Game');


test ('kart seçimi', ()=>{

const driver=mount(<Game/>);


    let card = driver.find('.kart').at(0);
    card.simulate('click');
    card.find("img").prop("src");
    let srcName=card.image;


})

test('oyun sonucu',()=>{

    const driver=mount(<Game/>);

    let card = driver.find('.kart').at(0);
    card.simulate('click');
    card = driver.find('.kart').at(1);
    card.simulate('click');
    card = driver.find('.kart').at(2);


})

test('yeni oyun',()=>{

    const driver=mount(<Game/>);

    let cart=driver.find('.kart').at(0);
    cart.simulate('click');
    expect(cart === 'img/Kedi.jpg');
    let oyun =driver.find('.link');
    oyun.simulate('click');


})

